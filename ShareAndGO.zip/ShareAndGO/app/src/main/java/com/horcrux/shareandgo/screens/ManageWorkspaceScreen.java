package com.horcrux.shareandgo.screens;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.horcrux.shareandgo.R;

public class ManageWorkspaceScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_workspace_screen);



    }
}
